function [R, P] = correlationCoefficients_RR(features,numFeatures)

% Initialize the correlation matrices
R = zeros(numFeatures);
P = zeros(numFeatures);

% Loop through the 'rows' of the coefficient matrices
for rowIndex = 1:numFeatures
    
    % Loop through the 'columns' of the coefficient matrices
    for colIndex = 1:numFeatures
        
        % Feature values for this row
        rowFeature = features(:,rowIndex);
        
        % Feature values for this column
        colFeature = features(:,colIndex);
        
        % Determine the R values and P values between these two features
        [Rtemp,Ptemp] = corrcoef(rowFeature,colFeature);
        
        R(rowIndex,colIndex) = Rtemp(1,2);
        P(rowIndex,colIndex) = Ptemp(1,2);
        
    end

end