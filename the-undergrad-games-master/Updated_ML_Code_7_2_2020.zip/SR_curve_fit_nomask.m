function J = SR_curve_fit_nomask(x, levels, SR)

% Extract the previous iteration's returned values
A0_hat = x(1);
l_hat = x(2);
w0_hat = x(3);
f_hat = x(4);
B_hat = x(5);

% interpolate SR
X = linspace(min(levels),max(levels),1000);

SR_interp = interp1(levels,SR,X);

levels = levels';

% Generate the SR curve using these data
r = (l_hat./(sqrt(2)*pi)).*exp(-l_hat^2./(2*((X-f_hat).^2)));
F = B_hat - (A0_hat.*l_hat./(X - f_hat).^2).*r./sqrt(4.*r.^2 + w0_hat^2).*(X-f_hat).*(X >=f_hat);

% The cost function
J = sum((SR_interp - F).^2);

end