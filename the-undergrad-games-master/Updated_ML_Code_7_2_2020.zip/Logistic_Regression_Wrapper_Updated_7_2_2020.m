%% BRAINSTIM LOGISTIC REGRESSION
% ===== BEGIN SETUP =========================================================================================================
% Let's go
clc;
clear;
close all;

% Global variables for curve fits
global thisSubjectSRNoiseLevels thisSubjectMeasuredThresholds TestType SRType method

%% USER INPUTS: Simulation setup

% [USER EDIT]: The number of features you have
numberOfFeatures = 4;

% [USER EDIT]: Number of simulations to run
numberOfSimulations = 10;

% [USER EDIT]: Probability of exhibiting SR
probabilityOfSR = 0.5; % Must be between 0 and 1. Here, 50% chance.

% [USER EDIT]: Which subject profile to use
subjectProfile = 1; % 1 = dip at lower SR noise levels, 2 = dip at higher SR noise levels

% [USER EDIT]: Plot the SR curve fits? Will only plot first 10 subjects
plotSRCurveFits = 1;

% [USER EDIT]: Plot histograms of the features?
plotFeatureHistograms = 1;

% [USER EDIT]: Define what type of SR is being used
SRType = 2;  % 1 = ASR, 2 = VSR

% [USER EDIT]: Define what type of sensory threshold is being measured
TestType = 2; % 1 = Visual, 2 = Auditory, 3 = Tactile, 4 = Vestibular

% [USER EDIT]: Determine whether we expect masking or not
maskingExpected = (TestType == 2 && SRType == 1);

% [USER EDIT]: The method by which we define the width of the curve when
% doing curve fits
method = 'Derivative';

% [USER EDIT]: The proportion of training to test from this data set
trainTestRatio = 0.8; % Must be between 0 and 1. Here, 80% used to train
%% Task Setup

% Matrix of all underlying parameters
allUnderlyingParameters = zeros(7,numberOfSimulations);

% Matrix of all fitted parameters
allFittedParameters = zeros(7,numberOfSimulations);

% Matrix of underlying thresholds
allUnderlyingThresholds = [];

% Matrix of fitted thresholds
allMeasuredThresholds = [];

% The features matrix
features = zeros(numberOfSimulations,numberOfFeatures);

% The feature names cell array
featureNames = {};

% [USER EDIT]: Determine which subjects have SR. 

% subjectsWithSR = rand(numberOfSimulations,1) <= probabilityOfSR;
subjectsWithSR = zeros(numberOfSimulations,1);
subjectsWithSR(1:2:end) = 1;

% The underlying parameters for subjects who exhibit SR. May be changed for
% different task types.
switch SRType
    
    case 1
        
        switch TestType
            
            case 1
                
                % ASR Visual
                A0 = 0.7;
                lambda = 5;
                w0 = 5;
                m = 0;
                s = 0;
                if subjectProfile == 1
                    f = 30.01;
                else
                    f = 55.01;
                end
                B = 0.15;
                
                % The expected standard deviation of baseline thresholds
                B_sd = 0.05;
                
                % Curve plot axes limits
                Ymin = 0;
                Ymax = 1;
                
            case 2
                
                % ASR Auditory
                A0 = 244.2;
                lambda = 3;
                w0 = 50;
                if subjectProfile == 1
                    f = 0.01;
                else
                    f = 15.01;
                end
                B = 8;
                m = 0.6;
                s = 25;
                
                % Expected standard deviation of baseline thresholds
                B_sd = 1.5;
                
                % Curve plot axes
                Ymin = -5;
                Ymax = 20;
                
            case 3
                
                % ASR Tactile
                A0 = 0.342;
                lambda = 5;
                w0 = 5;
                m = 0;
                s = 0;
                if subjectProfile == 1
                    f = 30.01;
                else
                    f = 55.01;
                end
                B = 0.15;
                
                % Expected standard deviation of baseline thresholds
                B_sd = 0.05;
                
                % Curve plot axes
                Ymin = 0;
                Ymax = 1;
                
        end
        
    case 2 % VSR
        
        switch TestType
            
            case 1
                
                % VSR Visual
                A0 = 0.342;
                lambda = 0.1;
                w0 = 0.1;
                m = 0;
                s = 0;
                if subjectProfile == 1
                    f = 0.201;
                else
                    f = 0.601;
                end
                B = 0.15;
                
                % Expected standard deviation of baseline thresholds
                B_sd = 0.05;
                
                % Curve plot axes
                Ymin = 0;
                Ymax = 0.3;
                
            case 2
                
                % VSR Auditory
                A0 = 15.158;
                lambda = 0.1;
                w0 = 0.1;
                m = 0;
                s = 0;
                if subjectProfile == 1
                    f = 0.201;
                else
                    f = 0.601;
                end
                B = 8;
                
                % Expected standard deviation of baseline thresholds
                B_sd = 1.5;
                
                % Curve plot axes
                Ymin = -5;
                Ymax = 20;
                
            case 3
                
                % VSR Tactile
                A0 = 0.342;
                lambda = 0.1;
                w0 = 0.1;
                m = 0;
                s = 0;
                if subjectProfile == 1
                    f = 0.201;
                else
                    f = 0.601;
                end
                B = 0.15;
                
                % Expected standard deviation of baseline thresholds
                B_sd = 0.05;
                
                % Curve plot axes
                Ymin = 0;
                Ymax = 1;
        end
end
% Generate the underlying curve parameters
underlyingCurveParameters = [A0;
    lambda;
    w0;
    m;
    s;
    f;
    B];
%% Guesses for curve fits
if maskingExpected % Case with masking
    
    % Use all the parameters. Must be modified slightly so initial guesses
    % don't cause infinite values in first evaluation
    curveFitGuesses = underlyingCurveParameters;
    
else % No masking
    
    % Don't use parameters that define masking. Must be modified slightly
    % so initial guesses don't cause infinite values in first evaluation.
    curveFitGuesses = [underlyingCurveParameters(1:3);underlyingCurveParameters(6:7)];
    
end

%% Upper and lower bounds on curve fit parameters
if maskingExpected % Case with masking
    
    % Upper bounds on all 7 parameters
    UpperBounds = [1e10;
        1e10;
        1e10;
        1e10;
        1e10;
        1e10;
        1e10];
    
    % Lower bounds on all 7 parameters
    LowerBounds = [1e-6;
        1e-6;
        1e-6;
        1e-6;
        1e-6;
        1e-6;
        1e-6];
    
else % No masking
    
    % Upper bounds on 5 relevant parameters
    UpperBounds = [1e10;
        1e10;
        1e10;
        1e10;
        1e10];
    
    % Lower bounds on 5 relevant parameters
    LowerBounds = [1e-6;
        1e-6;
        1e-6;
        1e-6;
        1e-6];
end

%% Curve fit options

% [USER EDIT]: Change the display options to show whether curve fits
% converge
options = optimoptions('fmincon','Display','off');

% [USER EDIT]: Change warning display
warning('off');

% ===== END SETUP | BEGIN SIMULATION ====================================================================================================================

%% Begin simulating subjects

% Loop through all the simulated subjects
for simulation = 1:numberOfSimulations
    
    %% Simulate the subject
    % Determine whether this subject has SR
    subjectHasSR = subjectsWithSR(simulation);
    
    % Determine the underlying curve parameters. As of now, the only thing
    % subject to change from the values given above is the sham threshold.
    % You can do this for any of the curve fit parameters
    underlyingShamThreshold = normrnd(B,B_sd);
    
    % Re-determine the sham threshold if it's not in the acceptable range
    while (TestType ~= 2 && (underlyingShamThreshold <= 0 || underlyingShamThreshold >= 1))
        
        % We only do this for non-auditory tasks
        underlyingShamThreshold = normrnd(B,B_sd);
    end
    
    % Modify A0 to maintain the appropriate dip
    thisSubjectA0 = A0.*(underlyingShamThreshold./B);
    
    % Determine all the underlying curve parameters, maintaining 30% dip
    thisSubjectUnderlyingCurveParameters = [thisSubjectA0;underlyingCurveParameters(2:6);underlyingShamThreshold];
    
    % [USER EDIT]: Determine the SR noise levels. This could be constant or based on
    % their sham threshold.
    % thisSubjectSRNoiseLevels = [0:0.1:1];  % [0,30:5:80] for ASR, or change how you like!
    % for ASR auditory:
    thisSubjectSRNoiseLevels = [-15,underlyingShamThreshold+[-10,-5,0,5,10,15],40];
    
    % [USER EDIT]: Determine the number of trials used in the task
    numberOfTrials = 50;
    
    % Simulate the subject. Same function call can be made for any subject
    % simulation (i.e. retest). To do this, change:
    % thisSubjectSRNoiseLevels
    % numberOfTrials
    [thisSubjectUnderlyingThresholds, thisSubjectMeasuredThresholds] = simulateSubject_RR(thisSubjectSRNoiseLevels,thisSubjectUnderlyingCurveParameters,numberOfTrials,subjectHasSR);
    
    %% Curve Fitting
    
    % Determine whether masking is expected
    if maskingExpected
        
        % The fmincon function that returns all the curve fit parameters, for
        % cases where masking is expected
        curveFitRawParameters = fmincon(@(curveFitParameters) SR_curve_fit_withmask(curveFitParameters,thisSubjectSRNoiseLevels,thisSubjectMeasuredThresholds),curveFitGuesses,[],[],[],[],LowerBounds,UpperBounds,@SR_minWidth_maxDepth_Updated,options);
        
        % Extract all the fitted values
        A0_fit = curveFitRawParameters(1);
        lambda_fit = curveFitRawParameters(2);
        w0_fit = curveFitRawParameters(3);
        m_fit = curveFitRawParameters(4);
        s_fit = curveFitRawParameters(5);
        f_fit = curveFitRawParameters(6);
        B_fit = curveFitRawParameters(7);
        
    else
        
        % The fmincon function that returns all the curve fit parameters, for
        % cases where no masking is expected
        [curveFitRawParameters,J,flag] = fmincon(@(curveFitParameters) SR_curve_fit_nomask(curveFitParameters,thisSubjectSRNoiseLevels,thisSubjectMeasuredThresholds),curveFitGuesses,[],[],[],[],LowerBounds,UpperBounds,@SR_minWidth_maxDepth_Updated,options);
        
        % Extract all the fitted values
        A0_fit = curveFitRawParameters(1);
        lambda_fit = curveFitRawParameters(2);
        w0_fit = curveFitRawParameters(3);
        m_fit = 0;
        s_fit = 0;
        f_fit = curveFitRawParameters(4);
        B_fit = curveFitRawParameters(5);
        
    end
    
    % Organize all of the curve fit parameters into a nice, neat vector
    curveFitParameters = [A0_fit;
        lambda_fit;
        w0_fit;
        m_fit;
        s_fit;
        f_fit;
        B_fit];
    
    % Clear the raw parameters for the next iteration
    clear curveFitRawParameters;
    
    %% Calculate the fitted curve
    X = linspace(min(thisSubjectSRNoiseLevels),max(thisSubjectSRNoiseLevels),1000);
    
    % Interim calculation of r
    r = (lambda_fit./(sqrt(2)*pi)).*exp(-lambda_fit^2./(2*((X-f_fit).^2)));
    
    % Calculate the SR dip
    SRDip = B_fit - (A0_fit.*lambda_fit./(X - f_fit).^2).*r./sqrt(4.*r.^2 + w0_fit^2).*(X-f_fit).*(X >=f_fit);
    
    % Calculate masking effects
    mask = m_fit*(X-s_fit).*(X >= s_fit);
    
    % Determine the fitted thresholds
    SRCurveFit = SRDip + mask;
    
    %% Example retest procedures
    
    % If you wanted to do retesting, it might look like somthing like this:
    
    % Let's say we want to do a different number of trials
    retestTrials = 100;
    
    % Determine the retest levels. Sham, and best in this instance.
    retestLevels = [thisSubjectSRNoiseLevels(1),thisSubjectSRNoiseLevels(1+find(thisSubjectMeasuredThresholds(2:end) == min(thisSubjectMeasuredThresholds(2:end))))];
    
    % Simulate the retest
    [underlyingRetestThresholds,measuredRetestThresholds] = simulateSubject_RR(retestLevels,thisSubjectUnderlyingCurveParameters,retestTrials,subjectHasSR);
    
    % You may now do what you wish with this data!!! I'm going to plot it.
    
    
    %% Plot this subject's information, if applicable
    
    if (plotSRCurveFits == 1 && simulation <= 10)
        
        % Generate the underlying SR curve
        
        if subjectHasSR == 1
            % Interim calculation of r
            r = (lambda./(sqrt(2)*pi)).*exp(-lambda^2./(2*((X-f).^2)));
            
            % Calculate the SR dip
            underlyingSRDip = underlyingShamThreshold - (thisSubjectA0.*lambda./(X - f).^2).*r./sqrt(4.*r.^2 + w0^2).*(X-f).*(X >=f);
            
            % Calculate masking effects
            underlyingMask = m_fit*(X-s_fit).*(X >= s_fit);
            
            % Determine the underlying thresholds
            underlyingSRCurve = underlyingSRDip + underlyingMask;
            
            % If this subject does not have SR, the underlying curve is
            % flat but may still have masking
        else
            underlyingSRCurve = underlyingShamThreshold*ones(size(X)) + m_fit*(X-s_fit).*(X >= s_fit);
        end
        
        % Plot the first 10 curve fits!
        figure(1);
        subplot(2,5,simulation);
        hold on;
        plot(X,underlyingSRCurve,'k','LineWidth',2);
        plot(thisSubjectSRNoiseLevels,thisSubjectMeasuredThresholds,'b--*','LineWidth',2);
        plot(X,SRCurveFit,'r','LineWidth',2);
        plot(retestLevels,measuredRetestThresholds,'co','LineStyle','none','LineWidth',2,'MarkerSize',10);
        plot(retestLevels,underlyingRetestThresholds,'x','Color',[0.5 0.8 0.5],'LineStyle','none','LineWidth',2,'MarkerSize',10);
        titlestr = sprintf('Subject %d: ',simulation);
        if subjectHasSR == 1
            SRstr = 'Has SR';
        else
            SRstr = 'No SR';
        end
        title([titlestr,SRstr]);
        xlabel('SR Noise Level');
        ylabel('Threshold');
        legend('Underlying Curve','Measured Thresholds','Fitted Curve','Retest Data','Underlying Retest');
        
        % The plot axes
        axis([min(thisSubjectSRNoiseLevels) max(thisSubjectSRNoiseLevels) Ymin Ymax]);
    end
    %% Concatenate all the measurements
    
    % Start with all the underlying curve parameters
    allUnderlyingParameters(:,simulation) = thisSubjectUnderlyingCurveParameters;
    
    % And add all the fitted curve paramters
    allFittedParameters(:,simulation) = curveFitParameters;
    
    % Add all the underlying thresholds!
    allUnderlyingThresholds = [allUnderlyingThresholds;thisSubjectUnderlyingThresholds];
    
    % Add the measured thresholds!
    allMeasuredThresholds = [allMeasuredThresholds;thisSubjectMeasuredThresholds];
    
    % NOTE: Keep in mind that the size of the measured thresholds vector
    % can change as you do retest and interim analysis. You can modify
    % these concatenations however you wish so you can incorporate what you
    % want.
    
    %% Additional information about this subject (optional)
    
    % Initial measured sham threshold
    initialShamThreshold = thisSubjectMeasuredThresholds(1);
    
    % Retest sham threshold
    retestShamThreshold = measuredRetestThresholds(1);
    
    % Average sham threshold
    averageShamThreshold = (initialShamThreshold + retestShamThreshold)./2;
    
    % Fitted sham threshold
    fittedShamThreshold = B_fit;
    
    % Initial 'best' threshold
    initialBestThreshold = min(thisSubjectMeasuredThresholds(2:end));
    
    % Retest best threshold
    retestBestThreshold = measuredRetestThresholds(2);
    
    % Average best thresholds
    averageBestThreshold = (initialBestThreshold + retestBestThreshold)./2;
    
    %% Subject complete! Define features here
% ===== END SIMULATION | BEGIN FEATURE DEFINITION ====================================================================================================================
    
    %% Feature: Add your features here!
    
    % Note: Here, only calculate one single value. At the very bottom of
    % this for loop is a section dedicated entirely to the features matrix.
    
    %% Feature: Standard deviation of thresholds
    
    % Get every threshold we measured
    allSubjectThresholds = [thisSubjectMeasuredThresholds,measuredRetestThresholds];
    
    % Calculate the standard deviation
    StandardDeviationOfThresholds = std(allSubjectThresholds);
    
    %% Feature: Area under the curve fit
    
    % Isolate the dip in the fitted curve
    curveFitDipOnly = SRCurveFit - B_fit - mask;
    
    % Calcuate the area of the dip in the fitted curve
    AreaOfCurveFit = abs(trapz(X,SRCurveFit));
    
    %% Feature: Difference between best and retest best, normalized by sham
    
    % Measure difference between best and retest best
    BestToRetestBestByAvgSham = abs(initialBestThreshold - retestBestThreshold)./averageShamThreshold;
    
    %% Feature: Average best to average sham, normalized by sham
    
    % Measure distance between average sham and best, normalize by average
    % sham
    AvgBestToAvgSham = (averageShamThreshold - averageBestThreshold)./averageShamThreshold;
    
    %% [USER EDIT]: The features matrix. 
    %  Easier to keep it in one place.
    
    % Build up the features matrix
    features(simulation,1) = StandardDeviationOfThresholds;
    features(simulation,2) = AreaOfCurveFit;
    features(simulation,3) = BestToRetestBestByAvgSham;
    features(simulation,4) = AvgBestToAvgSham;
    
end
    
    % Build up the feature names cell array
    featureNames{1} = 'Standard Deviation of Thresholds';
    featureNames{2} = 'Area of Curve Fit';
    featureNames{3} = 'Difference of Best and Retest Best';
    featureNames{4} = 'Difference between Average Sham and Average Best';
    
    % Make sure to update the number of features in line 14!

% ===== END FEATURE DEFINITION | BEGIN ANALYSIS ============================================================================================================
%% Plot the feature histograms, if desired

% Only make plots if plots are desired
if plotFeatureHistograms == 1
    
    % Loop through all the features
    for featureIndex = 1:numberOfFeatures
        
        % Isolate the current feature
        currentFeatureValues = features(:,featureIndex);
        
        % Determine the values of the feature for subjects with SR
        featureWithSR = currentFeatureValues(find(subjectsWithSR == 1));
        
        % Determine the values of the feature for subjects without SR
        featureWithNoSR = currentFeatureValues(find(subjectsWithSR == 0));
        
        % This feature's bin width
        thisBinWidth = abs(max(currentFeatureValues)-min(currentFeatureValues))./10;
        
        % Plot 'em!
        figure;
        hold on;
        histogram(featureWithSR,'BinWidth',thisBinWidth,'EdgeColor','blue','FaceColor','blue');
        histogram(featureWithNoSR,'BinWidth',thisBinWidth,'EdgeColor','green','FaceColor','green','FaceAlpha',0.2);
        titlestr = ['Feature ',num2str(featureIndex),': ',featureNames{featureIndex}];
        title(titlestr);
        xlabel('Feature Value');
        ylabel('Number of Occurrences');
        legend('With SR','No SR');
        
    end
    
end

%% Split data into training and test sets

    % Determine where to split the data based on the train/test ratio
    split_ind = floor(trainTestRatio*numberOfSimulations); 

    % Determine the training set of features
    Xtrain = features(1:split_ind,:);
    
    % Determine the training set of SR vs No SR
    Ytrain = categorical(subjectsWithSR(1:split_ind));
    
    % Determine the test set of features
    Xtest = features((split_ind+1):end,:);
    
    % Determine the test set of SR vs No SR
    Ytest = categorical(subjectsWithSR((split_ind+1):end));

%% Fit model to training set

    [Beta,dev,stats] = mnrfit(Xtrain,Ytrain,'interactions','on');
    % Matlab's built in multinominal logistic regression function

%% Predict probabilities for test set

    Predicted_probabilities = mnrval(Beta, Xtest);

%% Confusion matrices

    % This helps us understand the accuracy of the code. Returns a confusion matrix and tells us information about it 
    [YPredicted,confusion, Accuracy, ActualNo, PredictedNo, ActualYes, PredictedYes,TrueNeg,FalseNeg,FalsePos,TruePos] = confusionMatrix_Updated(Predicted_probabilities,Ytest);

%% Chi-squared and P-Values

    % Chi^2 test gives p-value
    [p_chi2] = chiSquared(ActualNo,PredictedNo,ActualYes,PredictedYes,TrueNeg,FalseNeg,FalsePos,TruePos);
    
%% Correlation Coefficients
 
    % Determine the correlation coefficients
   [R_values, P_values] = correlationCoefficients_RR(features,numberOfFeatures);
   
% ===== END ANALYSIS | END PROGRAM ==========================================================================================================