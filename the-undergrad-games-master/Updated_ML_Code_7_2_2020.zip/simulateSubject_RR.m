function [underlyingThresholds,measuredThresholds] = simulateSubject_RR(SRNoiseLevels,SRCurveParameters,trials,withSR)

%% Documentation
%  This function simulates a subject's underlying and measured perceptual
%  thresholds in a two-interval forced choice task that uses a 3-down 1-up
%  PEST procedure.

%  Inputs:
%   SRNoiseLevels: A 1xM vector of the M SR noise levels being simulated
%   SRCurveParameters: A 7x1 vector containing the paramters that define
%     the underlying curve: [A0; lambda; w0; m; s; f; B]
%   trials: Either a single value or 1xM vector determining how many trials
%     to do at each SR noise level. Applies to PEST procedure only.
%   withSR: Determines whether this subject exhibits SR.

%  Outputs:
%   underlyingThresholds: The subject's actual thresholds
%   measuredThresholds: The thresholds measured by the simulation. Use
%     these in feature definition.

% Since TestType is already a global variable, we might as well use it to
% inform which procedure we use.
global TestType

%% Generate the underlying thresholds

% Extract the SR curve parameters
A0 = SRCurveParameters(1);
lambda = SRCurveParameters(2);
w0 = SRCurveParameters(3);
m = SRCurveParameters(4);
s = SRCurveParameters(5);
f = SRCurveParameters(6);
B = SRCurveParameters(7);

% Calculate the underlying thresholds
if withSR == 1
    
    % Interim calculation of r
    r = (lambda./(sqrt(2)*pi)).*exp(-lambda^2./(2*((SRNoiseLevels-f).^2)));
    
    % Calculate the SR dip
    SRDip = B - (A0.*lambda./(SRNoiseLevels - f).^2).*r./sqrt(4.*r.^2 + w0^2).*(SRNoiseLevels-f).*(SRNoiseLevels >=f);
    
    % Calculate masking effects
    mask = m*(SRNoiseLevels-s).*(SRNoiseLevels >= s);
    
    % Determine the underlying thresholds
    underlyingThresholds = SRDip + mask;
    
else
    
    % Calculate masking effects
    mask = m*(SRNoiseLevels-s).*(SRNoiseLevels >= s);
    
    % If no SR is present, thresholds are constant
    underlyingThresholds = B.*ones(size(SRNoiseLevels)) + mask;
    
end
%% Simulate the subject and get their measured thresholds.
%  This example simulates the PEST procedure.

% For fitting the psychometric curve, we need a few pieces of information!
% The rate at which the subject will guess correctly at low stimulus
% levels
guessRate = 0.5;
% The rate at which the subject will 'lapse' and get a trial wrong that
% they should get right. For this purpose, we assume no lapses.
lapseRate = 0;
% Here, we assume that the value of sigma is 0.3 times the value of the
% underlying sham threshold
sigma = underlyingThresholds(1)*0.3;
% We also have an initial guess of sigma
sigmaGuess = sigma;
% Do you want plots?
plotOn = 0;
% The initial stimulus level for the PEST procedure
if TestType == 2
    initialStim = 10;
else
    initialStim = 1;
end

% We're assuming that the variable "trials" is either a single value (in
% which case, all thresholds are measured with the same number of trials)
% or the same size as the vector of levels
if length(trials) == 1
    
    % Store how many trials we are using
    numTrials = trials;
    
    % Make the vector of trials the same size as the vector of SR noise
    % levels
    trials = numTrials*ones(size(SRNoiseLevels));
end

% Initialize measured thresholds
measuredThresholds = zeros(size(SRNoiseLevels));

% Simulate the thresholds
for SRNoiseLevel = 1:length(SRNoiseLevels)
    
    % What is the underlying threshold at this SR noise level?
    thisUnderlyingThreshold = underlyingThresholds(SRNoiseLevel);
    
    % The underlying threshold will also be our guess when fitting the
    % psychometric curve
    thresholdGuess = thisUnderlyingThreshold;
    
    % How many trials are we doing?
    thisThresholdTrials = trials(SRNoiseLevel);
    
    % Perform the PEST procedure
    if TestType == 2
        
        % Do the auditory PEST procedure
        [taskStimulusLevels,subjectRawResponses,correctResponses,lapses] = pest_mod_2int_Audio(thisThresholdTrials, thisUnderlyingThreshold, sigma, guessRate, lapseRate, plotOn, initialStim);
        
    else
        % Do the default PEST procedure
        [taskStimulusLevels,subjectRawResponses,correctResponses,lapses] = pest_mod_2int(thisThresholdTrials, thisUnderlyingThreshold, sigma, guessRate, lapseRate, plotOn, initialStim);
        
    end
    % Fit the psychometric curve
    psychometricCurveFit = fminsearch(@(psychometricCurveFit) two_int_fit_simp(psychometricCurveFit, taskStimulusLevels, correctResponses), [thresholdGuess, sigmaGuess]);
    
    % Add the simulated threshold to the list of thresholds
    measuredThresholds(SRNoiseLevel) = psychometricCurveFit(1);
    
end

end